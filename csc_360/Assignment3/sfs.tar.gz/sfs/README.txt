Joe Czepil
V00774878
CSC 360 Assignment 3
Simple File System



==Attached Files==

csc360a3.c
README.txt
makefile



==Incomplete Code/Methods==

void append_file()
	--This was supposed to be for reading multiple blocks into a file however I could not get it to work
	--A section in void find_filename_part3() is commented how that was supposed to run append_file()

void diskput()
copy_file()
update_fat()
add_directory_entries()
	--The four functions above were all partially implemented for PART 4 however none of them are working correctly at the moment.